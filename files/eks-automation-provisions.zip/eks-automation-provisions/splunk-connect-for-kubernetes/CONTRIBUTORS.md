# Contributors

Splunk Connect for Kubernetes is developed by Splunkers and the open-source community.

We thank all of our [contributors](https://github.com/splunk/splunk-connect-for-kubernetes/graphs/contributors)!

**For the detailed history of contributions** of a given file, try

    git blame file

to see line-by-line credits and

    git log --follow file

to see the change log even across renames and rewrites.
